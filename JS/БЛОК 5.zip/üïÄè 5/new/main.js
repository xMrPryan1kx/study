window.main = (function (lib) {
    lib.start();
})(window.lib);