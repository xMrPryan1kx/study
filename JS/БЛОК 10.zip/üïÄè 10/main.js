const btnEdit = document.querySelector('.edit');
const btnSave = document.querySelector('.save');
const btnCancel = document.querySelector('.cancel');
// const input = document.querySelector('input');
// const startHtml = input.value;
const div = document.querySelector('.edit-text')
const startHtmlDiv = div.innerHTML;
const date = new Date();
// const date1 = date;
// const select = document.querySelector('select');

const display = (inp, display) => inp.style.display = display;

// !для дива
const isValueDiv =() => {
    if (localStorage.getItem('text')) {
        div.innerHTML = localStorage.getItem('text')
    } else {
        div.innerHTML = startHtmlDiv;
    }
}
isValueDiv()

btnEdit.addEventListener('click', () => {
    div.contentEditable = 'true';
    div.focus();
    // input.selectionStart = input.value.length;
    display(btnSave, 'block')
    display(btnCancel, 'block')
    display(btnEdit, 'none')
    
})
btnSave.addEventListener('click', () => {
    let nowDate = date.getMilliseconds();
    localStorage.setItem('date', nowDate);
    localStorage.setItem('text', div.innerHTML);
    display(btnSave, 'none');
    display(btnCancel, 'none');
    display(btnEdit, 'block')
    div.contentEditable = 'false';
})
btnCancel.addEventListener('click', () => {
    isValueDiv()
    display(btnSave, 'none');
    display(btnCancel, 'none');
    display(btnEdit, 'block')
    div.contentEditable = 'false';
})





// !для инпута
// const isValue =() => {
//     if (localStorage.getItem('text')) {
//         input.value = localStorage.getItem('text')
//     } else {
//         input.value = startHtml;
//     }
// }
// isValue()



// btnEdit.addEventListener('click', () => {
//     input.focus();
//     input.selectionStart = input.value.length;
//     display(btnSave, 'block')
//     display(btnCancel, 'block')
    
// })


// btnSave.addEventListener('click', () => {
//     let nowDate = date.getMilliseconds();
//     localStorage.setItem('date', nowDate);
//     localStorage.setItem('text', input.value);
//     display(btnSave, 'none')
//     display(btnCancel, 'none')
// })
// btnCancel.addEventListener('click', () => {
//     isValue()
//     display(btnSave, 'none')
//     display(btnCancel, 'none')
// })


// input.value = localStorage.getItem('text');

// test1 = JSON.parse(localStorage.getItem('test'))
// select.innerHTML = `<option>${test1}</option>`;

// btnEdit.addEventListener('click', () => {
//     input.focus();
//     // input.select();
//     input.selectionStart = input.value.length;
// })

// const user = {
//     name: 'Alex',
//     age: 26,
//     time: date1
// }
// const test = {}

// btnOk.addEventListener('click', () => {
//     test.date1 = date1;
//     select.innerHTML= `<option>${date1}</option>`;
//     localStorage.setItem('test', JSON.stringify(test));
    
    
// })

// const times = {
//     'Fri May 01 2020 23:45:07 GMT+0300 (Москва, стандартное время)': 'Fri May 01 2020 23:45:07 GMT+0300 (Москва, стандартное время)',
//     'Fri May 01 2020 23:46:32 GMT+0300 (Москва, стандартное время)': 'Fri May 01 2020 23:46:32 GMT+0300 (Москва, стандартное время)'
// };
// const delay = localStorage.getItem('obj');
// const delay1 = JSON.parse(delay)

// for (const time in delay1) {
//     if
// }

// btnOk.addEventListener('click', (e) => {
//     e.preventDefault();
//     times[date1] = date1;
//     timesJson = JSON.stringify(times);
//     localStorage.setItem('obj',timesJson);
// })







